karateclub.dataset
========================

.. automodule:: karateclub.dataset.dataset_reader
    :members:
    :undoc-members:
